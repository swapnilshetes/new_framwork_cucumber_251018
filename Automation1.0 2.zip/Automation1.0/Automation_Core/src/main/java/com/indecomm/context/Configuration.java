package com.indecomm.context;

public class Configuration {

}
