package com.indecomm.data;

public class JSONProcessor implements DataProcessor {

	

	public Object getData() {
		
		return null;
	}

	public void processData(String fileName) {
		// TODO Auto-generated method stub
		
	}

}
