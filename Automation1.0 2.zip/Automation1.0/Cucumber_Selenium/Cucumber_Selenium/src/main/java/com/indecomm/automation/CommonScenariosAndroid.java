package com.indecomm.automation;

public class CommonScenariosAndroid extends AbstractScenarios {

}
