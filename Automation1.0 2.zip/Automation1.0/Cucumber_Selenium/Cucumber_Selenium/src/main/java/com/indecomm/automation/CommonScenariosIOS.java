package com.indecomm.automation;

public class CommonScenariosIOS extends AbstractScenarios {

}
